﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WarGame : MonoBehaviour {

	//Variables
	public GameObject PlayButton;

	public Dictionary<string, int> deckReference = new Dictionary<string, int>(); 
	public List<string> deck = new List<string>();

	public List<string> yourStack = new List<string>();
	public List<string> enemyStack = new List<string>();

	public List<string> warStack = new List<string>();

	public Text yourScore;
	public Text enemyScore;

	public Text yourCard;
	public Text enemyCard;


 	void Start () {
		populateDeck ();
		dealCards ();
		updateScore ();
	}

	//Update text to show each players current stack.
	void updateScore(){
		yourScore.text = "Your Score: " + yourStack.Count;
		enemyScore.text = "Enemy's Score: " + enemyStack.Count;
	}

	//This is the main function. Grab a random card from each stack and check them against each other.
	//If they are equal, call the War coroutine.
	//It is public so that the button can access it.
	public void pullCards() {

		if (checkWinner () == false) {
			//Get your card.
			int yourRan = Random.Range (0, yourStack.Count);
			string yourPulledCard = yourStack [yourRan];
			int yourPulledValue = deckReference [yourPulledCard];

			//Get enemy card.
			int enemyRan = Random.Range (0, enemyStack.Count);
			string enemyPulledCard = enemyStack [enemyRan];
			int enemyPulledValue = deckReference [enemyPulledCard];

			yourCard.text = yourPulledCard;
			enemyCard.text = enemyPulledCard;

			if (yourPulledValue > enemyPulledValue) {
				yourStack.Add (enemyStack [enemyRan]);
				enemyStack.RemoveAt (enemyRan);
				yourCard.text = yourCard.text + "\n WINNER!";
				warWinner (true);
			} else if (yourPulledValue < enemyPulledValue) {
				enemyStack.Add (yourStack [yourRan]);
				yourStack.RemoveAt (yourRan); 
				enemyCard.text = enemyCard.text + "\n WINNER!";
				warWinner (false);
			} else { 
				PlayButton.SetActive (false);

				yourCard.text = yourCard.text + "\n WAR!";
				enemyCard.text = enemyCard.text + "\n WAR!";


				warStack.Add (yourStack [yourRan]);
				yourStack.RemoveAt (yourRan);  
				warStack.Add (enemyStack [enemyRan]);
				enemyStack.RemoveAt (enemyRan);

				StartCoroutine (War ());

			}


			updateScore ();
			checkWinner ();
		} else {
			Scene scene = SceneManager.GetActiveScene(); SceneManager.LoadScene(scene.name);
		}
	}

	void dealCards(){

		bool yourDeal = true;
		while(deck.Count > 0){
			int randomNumber = Random.Range (0, deck.Count);

			if (yourDeal == true) {
				yourStack.Add (deck [randomNumber]);
				yourDeal = false;
			} else {
				enemyStack.Add (deck [randomNumber]);
				yourDeal = true;
			}
			deck.RemoveAt (randomNumber);

		}
	
	}


	void warWinner(bool youWin){
		while (warStack.Count > 0) {
			if (youWin == true) {
				yourStack.Add (warStack [warStack.Count - 1]);
			} else {
				enemyStack.Add (warStack [warStack.Count - 1]);
			}
			warStack.RemoveAt (warStack.Count - 1);
		}

	}


	bool checkWinner(){
		if(enemyStack.Count <= 0){
			yourCard.text = "You have won!";
			enemyCard.text = "You have won!";
			return true;
		}

		if(enemyStack.Count <= 0){
			yourCard.text = "You have lost!";
			enemyCard.text = "You have lost!";
			return true;
		}

		return false;

	}
		
	//Pause the game briefly so the player can register that a War is occuring then grab the facedown cards.
	IEnumerator War()
	{
		yield return new WaitForSeconds(2);

		//Check to see if the facedown card empties them out.
		if (checkWinner () == false) {
			//Face Down Card
			int yourRan = Random.Range (0, yourStack.Count);
			int enemyRan = Random.Range (0, enemyStack.Count);

			warStack.Add (yourStack [yourRan]);
			yourStack.RemoveAt (yourRan);  
			warStack.Add (enemyStack [enemyRan]);
			enemyStack.RemoveAt (enemyRan);
		 
			PlayButton.SetActive (true);

			pullCards ();
		} else {

			PlayButton.SetActive (true);

		}

	}


	//This function goes through and adds every card to the dictionary array. 
	void populateDeck(){

		int i = 2;
		int t = 1;
		string card = "";

		for (t = 1; t <= 4; t++) {
			for (i = 2; i <= 10; i++) {

				switch (t) {
				case 1:
					card = i + " of Spades";
					break;
				case 2:
					card = i + " of Hearts";
					break;
				case 3:
					card = i + " of Clubs";
					break;
				case 4:
					card = i + " of Diamonds";
					break;
				}
				deckReference.Add (card, i);
				deck.Add (card); 
			}
		}

		for (t = 1; t <= 4; t++) {
			for (int value = 11; value <= 14; value++) {

				switch (value) {
				case 11:
					card = "Jack";
					break;
				case 12:
					card = "Queen";
					break;
				case 13:
					card = "King";
					break;
				case 14:
					card = "Ace";
					break;
				}

				switch (t) {
				case 1:
					card = card + " of Spades";
					break;
				case 2:
					card = card + " of Hearts";
					break;
				case 3:
					card = card + " of Clubs";
					break;
				case 4:
					card = card + " of Diamonds";
					break;
				}
				 
				deckReference.Add (card, value);
				deck.Add (card);

			}
					 
		}
 
		 

	}
}
